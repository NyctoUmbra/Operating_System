#ifndef BLOCK_H
#define BLOCK_H

#include <string>
#include <vector>
#include <fstream>
#include <iostream>
using namespace std;

vector <string> block(string s, int b);

#endif
